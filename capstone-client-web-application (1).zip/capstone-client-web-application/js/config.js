const config = {
    baseUrl: 'http://localhost:8080'
}
